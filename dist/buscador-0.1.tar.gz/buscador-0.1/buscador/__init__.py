from buscador.classFindValue import FindValue
